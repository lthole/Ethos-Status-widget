return {
  scriptName = "Status3",
  source = "Source",
  state1def = "Parameter 1",
  state2def = "Parameter 2",
  state3def = "Parameter 3",
  state1Text = "Text Parameter 1",
  state2Text = "Text Parameter 2",
  state3Text = "Text Parameter 3",
  state1Threshold = "Schwellenwert 1",
  state2Threshold = "Schwellenwert 2",
  fontSize = "Schriftgröße",
  color1 = "Hintergrundfarbe 1",
  color2 = "Hintergrundfarbe 2",
  color3 = "Hintergrundfarbe 3",
  debugMode = "Werte für die Fehlersuche anzeigen",
  threshold = "Threshold"
}