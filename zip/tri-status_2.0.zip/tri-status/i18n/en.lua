return {
  scriptName = "Tri-Status",
  source = "Source",
  state1def = "State 1",
  state2def = "State 2",
  state3def = "State 3",
  state1Text = "State 1 Text Parameter",
  state2Text = "State 2 Text Parameter",
  state3Text = "State 3 Text Parameter",
  state1Threshold = "State 1 Threshold",
  state2Threshold = "State 2 Threshold",
  fontSize = "Font Size",
  color1 = "State 1 Background Color",
  color2 = "State 2 Background Color",
  color3 = "State 3 Background Color",
  debugMode = "Display values for debug",
  threshold = "Threshold"
}
