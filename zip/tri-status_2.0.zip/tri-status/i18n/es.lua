return {
  scriptName = "Estado3",
  source = "Fuente",
  state1def = "Estado 1",
  state2def = "Estado 2",
  state3def = "Estado 3",
  state1Text = "Estado 1 Parámetro de texto",
  state2Text = "Estado 2 Parámetro de texto",
  state3Text = "Estado 3 Parámetro de texto",
  state1Threshold = "Estado 1 Umbral",
  state2Threshold = "Estado 2 Umbral",
  fontSize = "Tamaño letra",
  color1 = "Estado 1 Color Fondo",
  color2 = "Estado 2 Color Fondo",
  color3 = "Estado 3 Color Fondo",
  debugMode = "Mostrar valores de depuración",
  threshold = "Threshold"
}
  