return {
  scriptName = "Stato3",
  source = "Sorgente",
  state1def = "Stato 1",
  state2def = "Stato 2",
  state3def = "Stato 3",
  state1Text = "Parametri Stato 1",
  state2Text = "Parametri Stato 2",
  state3Text = "Parametri Stato 3",
  state1Threshold = "Soglia Stato 1",
  state2Threshold = "Soglia Stato 2",
  fontSize = "Dimensione Font",
  color1 = "Colore Sfondo Stato 1",
  color2 = "Colore Sfondo Stato 2",
  color3 = "Colore Sfondo Stato 3",
  debugMode = "Mostra Valori per debug",
  threshold = "Parametri"
}