return {
  scriptName = "Status3",
  source = "Source",
  state1def = "Etat 1",
  state2def = "Etat 2",
  state3def = "Etat 3",
  state1Text = "Texte Etat 1",
  state2Text = "Texte Etat 2",
  state3Text = "Texte Etat 3",
  state1Threshold = "Seuil Etat 1",
  state2Threshold = "Seuil Etat 2",
  fontSize = "Taille de police",
  color1 = "Couleur Etat 1",
  color2 = "Couleur Etat 2",
  color3 = "Couleur Etat 3",
  debugMode = "Mode développeur",
  threshold = "Threshold"
}